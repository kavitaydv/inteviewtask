package com.isoftinc.taskproject.Fragment.Adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.bumptech.glide.Glide;
import com.isoftinc.taskproject.R;
import com.isoftinc.taskproject.databinding.LayoutImageSliderBinding;
import com.smarteist.autoimageslider.SliderViewAdapter;


public class SliderAdapter extends SliderViewAdapter<SliderAdapter.viewHolder> {
    private LayoutImageSliderBinding binding;

    @Override
    public int getCount() {
        return 6;
    }

    @Override
    public viewHolder onCreateViewHolder(ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        binding = LayoutImageSliderBinding.inflate(inflater, parent, false);
        return new viewHolder(binding);
    }

    @Override
    public void onBindViewHolder(viewHolder viewHolder, int position) {
        Glide.with(binding.getRoot().getContext())
                .load(R.drawable.laptop)
                .into(binding.ivAutoImageSlider);
    }

    public static class viewHolder extends SliderViewAdapter.ViewHolder {
        public viewHolder(LayoutImageSliderBinding view) {
            super(view.getRoot());
        }
    }
}
