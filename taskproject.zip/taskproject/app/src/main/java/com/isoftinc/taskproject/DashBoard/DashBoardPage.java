package com.isoftinc.taskproject.DashBoard;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.GravityCompat;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.isoftinc.taskproject.Fragment.HomeFragment;
import com.isoftinc.taskproject.R;
import com.isoftinc.taskproject.databinding.ActivityDashboardPageBinding;

public class DashBoardPage extends AppCompatActivity {

    private ActivityDashboardPageBinding binding;
    private boolean backPressedOnce = true;
    public static GoogleSignInOptions signInOptions;
    @SuppressLint("StaticFieldLeak")
    public static GoogleSignInClient signInClient;
    private TextView userNameDrawer;
    private RelativeLayout home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityDashboardPageBinding.inflate(getLayoutInflater());
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(binding.getRoot());
        userNameDrawer = findViewById(R.id.userNameDrawer);
        home = findViewById(R.id.home);

        signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        signInClient = GoogleSignIn.getClient(this,signInOptions);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null){
            userNameDrawer.setText(account.getEmail());
        }


        binding.menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.drawerLayout.isDrawerOpen(binding.navigationView)) {
                    binding.drawerLayout.closeDrawer(binding.navigationView);

                } else {
                    binding.drawerLayout.openDrawer(binding.navigationView);

                }
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.drawerLayout.closeDrawer(binding.navigationView);
               startActivity(new Intent(DashBoardPage.this, DashBoardPage.class));
            }
        });
    }

    @Override
    public void onBackPressed() {

        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)){
            binding.drawerLayout.closeDrawer(GravityCompat.START);
        }
       else if (backPressedOnce) {
            super.onBackPressed();
            return;
        }
    }
}