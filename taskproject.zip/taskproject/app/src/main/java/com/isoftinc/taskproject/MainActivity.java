package com.isoftinc.taskproject;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.isoftinc.taskproject.DashBoard.DashBoardPage;
import com.isoftinc.taskproject.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity{

    public ActivityMainBinding binding;

    @SuppressLint("StaticFieldLeak")
    public static GoogleSignInOptions signInOptions;
    @SuppressLint("StaticFieldLeak")
    public static GoogleSignInClient signInClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        setContentView(binding.getRoot());

        signInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        signInClient = GoogleSignIn.getClient(this,signInOptions);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account !=null){
            navigateToSeconActivity();
        }


        binding.rlLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = binding.edMobileno.getText().toString().trim();
                String password = binding.edPassword.getText().toString().trim();

                if (email.equalsIgnoreCase("")) {
                    Toast.makeText(MainActivity.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                } else if (password.equalsIgnoreCase("")) {
                    Toast.makeText(MainActivity.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                } else if (!email.equalsIgnoreCase("Kavya@gmail.com")) {
                    Toast.makeText(MainActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                } else if (!password.equalsIgnoreCase("Kavya@123")) {
                    Toast.makeText(MainActivity.this, "Invalid Password", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(MainActivity.this, DashBoardPage.class));
                    finish();
                }
            }
        });
        binding.rlGoogleLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }
    void signIn(){
        Intent intent = signInClient.getSignInIntent();
        startActivityForResult(intent,1000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

        try {
            task.getResult(ApiException.class);
            navigateToSeconActivity();
        } catch (ApiException e) {
            e.printStackTrace();
        }

    }

    private void navigateToSeconActivity() {

        finish();
        Intent intent = new Intent(getApplicationContext(),DashBoardPage.class);
        startActivity(intent);
    }
}